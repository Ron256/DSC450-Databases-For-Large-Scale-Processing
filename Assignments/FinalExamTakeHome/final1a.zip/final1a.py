import urllib.request
import json
import os
import csv
import time

os.chdir('C:/Users/rejalu1/OneDrive - Henry Ford Health System/DSC450/Assignments/FinalExamTakeHome')

tweetdata = """http://dbgroup.cdm.depaul.edu/DSC450/OneDayOfTweets.txt"""
startTime = time.time()                                                     # start time of processing the file in web

webFD = urllib.request.urlopen(tweetdata)
# csvf = open('OneDayOfTweets.csv', 'w', newline = '\n', encoding = 'utf-8')
csvf = open('OneDayOfTweets1a.csv', 'w', newline = '\n')
csve = open('OneDayOfTweetsError1a.csv', 'w', newline = '\n', encoding = 'utf-8')
for i in range(0, 200000):
    try:
        itemResponse = webFD.readline()                                     # read one line at a time
        strItemResponse = itemResponse.decode('utf-8')                      # decode the line that comes back from the web into a string.
        csvf.write(strItemResponse)
    
    except Exception:
        csve.write(strItemResponse)
    
csvf.close()                                                                 # close the file
csve.close()                                                                 # close the error file
endTime = time.time()                                                        # end time of processing of writing the tweets data to a file. 
print('The processing of the tweets data took %s seconds' %(endTime-startTime))
print('The number of operations per second is %s seconds' %(200000/(endTime-startTime)))